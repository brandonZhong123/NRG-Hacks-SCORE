<div class="bg-white text-gray-800 shadow p-4 flex justify-between items-center w-full ">

    <!-- Page heading -->
    <div class="text-xl font-semibold">
       {{ $pageHeading }} 
    </div>
    <div class="flex items-center gap-2">

        <!-- If user is a student -->
        @if(Auth::user()->role == 'student')
            <!-- Display random session booking link and tutor application link -->
            <a href="{{ route('tutors.submit-application') }}">
                <button class="bg-orange-500 px-4 py-2 rounded-full text-white hover:bg-orange-600">Apply For Tutor</button>
            </a>
        <!-- If user is a tutor -->
        @elseif(Auth::user()->role == 'tutor')
            <!-- If user status is enabled -->
            @if(Auth::user()->tutor->status == 'enabled')
                 <!-- Allow user to deactivate -->
                <form method="POST" action="{{ route('tutors.deactivate') }}"  >
                    @csrf
                    @method('PUT')
                    <button type="submit" class="bg-red-500 text-white py-2 px-4 rounded-full hover:bg-gray-600">Deactivate Tutor Profile</button>
                </form>
            <!-- If user status is disabled -->
            @elseif(Auth::user()->tutor->status == 'disabled')
                <!-- Allow user to enable -->
                <form method="POST" action="{{ route('tutors.activate') }}"   >
                    @csrf
                    @method('PUT')
                    <button type="submit" class="bg-green-500 text-white py-2 px-4 rounded-full hover:bg-green-600">Activate Tutor Profile</button>
                </form>
            @endif
        @endif

        <a href="{{ route('sessions.book-random-session') }}">
            <button class="bg-gray-500 px-4 py-2 rounded-full text-white hover:bg-gray-600">Request a Random Tutor Session</button>
        </a>

        <!-- Logout button -->
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit" class="bg-red-500 text-white py-2 px-4 rounded-full hover:bg-red-600">Logout</button>
        </form>
    </div>
</div>
