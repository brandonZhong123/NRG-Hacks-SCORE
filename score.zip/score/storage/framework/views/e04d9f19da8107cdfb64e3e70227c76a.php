
                    


<!-- filepath: /c:/xampp/htdocs/peer_tutor/resources/views/pages/users/update-profile.blade.php -->
<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Update Profile']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Update Profile')]); ?>
    <div class="bg-gray-100 flex justify-center items-center mt-8" style="min-height: 80vh;">
        <div class="bg-white shadow-md rounded-lg w-full max-w-4xl p-6">
            <div class="flex items-center mb-6">
                <img src="<?php echo e(asset('images/default.png')); ?>" alt="Profile Picture" class="w-20 h-20 rounded-full mr-4">
                <div>
                    <h2 class="text-xl font-bold"><?php echo e($tutor->user->first_name . ' ' . $tutor->user->last_name); ?></h2>
                </div>
            </div>
    
            <form method="POST" action="<?php echo e(route('tutors.update', $tutor->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <h3 class="text-lg font-semibold mb-4 border-b pb-2">Tutor Information</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Subjects</label>
                        <input type="text" name="subjects" value="<?php echo e($tutor->subjects); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Availability</label>
                        <input type="text" name="availability" value="<?php echo e($tutor->availability); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Phone Number</label>
                        <input type="text" name="phone_number" value="<?php echo e($tutor->phone_number); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Status</label>
                        <select name="role" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
                            <option value="enabled" <?php echo e($tutor->status == 'enabled' ? 'selected' : ''); ?>>Enabled</option>
                            <option value="disabled" <?php echo e($tutor->status == 'disabled' ? 'selected' : ''); ?>>Disabled</option>
                        </select>
                    </div>
                    <div class="col-span-1 md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700">Description</label>
                        <textarea name="description" rows="4" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200"><?php echo e($tutor->description); ?></textarea>
                    </div>

                    
                </div>
    
                <!-- Tutor Information -->
            
    
                <div class="flex justify-center mt-6">
                    <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 w-full">Save</button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/pages/tutors/update-profile.blade.php ENDPATH**/ ?>