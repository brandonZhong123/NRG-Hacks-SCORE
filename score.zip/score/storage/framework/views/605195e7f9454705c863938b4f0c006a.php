
<!-- Success Flash Message -->
<?php if(session('success')): ?>
    <div x-data="{show: true}" x-init="setTimeout(() => show = false, 3000)" x-show="show" class="bg-green-500 text-white p-4 rounded mb-4">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<!-- Error Flash Message -->
<?php if(session('error')): ?>
    <div x-data="{show: true}" x-init="setTimeout(() => show = false, 3000)" x-show="show" class="bg-red-500 text-white p-4 rounded mb-4">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\score\resources\views/components/flash-message.blade.php ENDPATH**/ ?>