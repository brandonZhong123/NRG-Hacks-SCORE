<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Dashboard')]); ?>
    <div class="flex-1 flex flex-col">
        <div class="flex-1 p-6 overflow-auto">
            <div class="bg-white shadow-lg rounded-lg p-6">
                <h1 class="text-2xl font-semibold text-gray-800">Overview of Your Tutoring Activities</h1>
                <p class="text-sm text-gray-500 mt-2">Here’s a summary of your sessions and other activities.</p>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-6">
                    <!-- Upcoming Sessions -->
                    <div class="bg-gray-100 p-4 rounded-lg shadow">
                        <h2 class="text-lg font-semibold text-gray-700">Upcoming Sessions</h2>
                        <?php if($dashboardContent['sessions']->isEmpty()): ?>
                            <p class="text-sm text-gray-600 mt-2">No upcoming sessions.</p>
                        <?php else: ?>
                            <div class="overflow-x-auto mt-4">
                                <table class="min-w-full bg-white rounded-lg">
                                    <thead>
                                        <tr>
                                            <!-- Table headers -->
                                            <th class="py-2 px-4 border-b text-left">Subject</th>
                                            <th class="py-2 px-4 border-b text-left">Date & Time</th>
                                            <th class="py-2 px-4 border-b text-left">Status</th>
                                            <th class="py-2 px-4 border-b text-left">
                                                <?php echo e(Auth::user()->role == 'tutor' ? 'Student' : 'Tutor'); ?>

                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Create table rows for each session -->
                                        <?php $__currentLoopData = $dashboardContent['sessions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <!-- Session information -->
                                                <td class="py-2 px-4 border-b"><?php echo e($session->subject); ?></td>
                                                <td class="py-2 px-4 border-b">
                                                    <?php echo e(date('l', strtotime($session->date))); ?>, 
                                                    <?php echo e((new DateTime($session->start_time))->format('h:i A')); ?>

                                                </td>
                                                <td class="py-2 px-4 border-b">
                                                    <?php if($session->status == 'Pending'): ?>
                                                        <span class="text-yellow-500"><?php echo e($session->status); ?></span>
                                                    <?php elseif($session->status == 'Accepted'): ?>
                                                        <span class="text-green-500"><?php echo e($session->status); ?></span>
                                                    <?php elseif($session->status == 'Denied'): ?>
                                                        <span class="text-red-500"><?php echo e($session->status); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="py-2 px-4 border-b">
                                                    <?php echo e(Auth::user()->role == 'tutor' ? $session->student->first_name : $session->tutor->first_name); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Session Requests -->
                    <div class="bg-gray-100 p-4 rounded-lg shadow">
                        <h2 class="text-lg font-semibold text-gray-700">Session Requests</h2>
                        <?php if($dashboardContent['sessionRequests']->isEmpty()): ?>
                            <p class="text-sm text-gray-600 mt-2">No session requests found.</p>
                        <?php else: ?>
                            <div class="overflow-x-auto mt-4">
                                <table class="min-w-full bg-white rounded-lg">
                                    <thead>
                                        <tr>
                                            <!-- Table headers -->
                                            <th class="py-2 px-4 border-b text-left">Subject</th>
                                            <th class="py-2 px-4 border-b text-left">Date & Time</th>
                                            <th class="py-2 px-4 border-b text-left">Status</th>
                                            <th class="py-2 px-4 border-b text-left">
                                                <?php echo e(Auth::user()->role == 'tutor' ? 'student' : 'Tutor'); ?>

                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Table rows for each session -->
                                        <?php $__currentLoopData = $dashboardContent['sessionRequests']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="py-2 px-4 border-b"><?php echo e($session->subject); ?></td>
                                                <td class="py-2 px-4 border-b">
                                                    <?php echo e(date('l', strtotime($session->date))); ?>, 
                                                    <?php echo e((new DateTime($session->start_time))->format('h:i A')); ?>

                                                </td>
                                                <td class="py-2 px-4 border-b">
                                                    <?php if($session->status == 'Pending'): ?>
                                                        <span class="text-yellow-500"><?php echo e($session->status); ?></span>
                                                    <?php elseif($session->status == 'Accepted'): ?>
                                                        <span class="text-green-500"><?php echo e($session->status); ?></span>
                                                    <?php elseif($session->status == 'Denied'): ?>
                                                        <span class="text-red-500"><?php echo e($session->status); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="py-2 px-4 border-b">
                                                    <?php echo e(Auth::user()->role == 'tutor' ? $session->student->first_name : ($session->tutor ? $session->tutor->first_name : 'Not Assigned')); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\score\resources\views/pages/dashboard/dashboard.blade.php ENDPATH**/ ?>