<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Pending Sessions']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Pending Sessions')]); ?>
    <!-- Page title -->
    <div class="p-6 w-full">
        <h1 class="text-2xl font-semibold text-gray-800 mb-6">Pending Sessions</h1>

        <!-- Check if there are any pending sessions -->
        <?php if($pendingSessions->isEmpty()): ?>

            <!-- Display different messages based on the user's role -->
            <?php if(Auth::user()->role != 'admin'): ?>
                <p class="text-gray-600">You have no pending sessions.</p> 
            <?php else: ?> 
                <p class="text-gray-600"> No pending sessions.</p> 
            <?php endif; ?>
        <?php else: ?>
            <div class="overflow-x-auto">
                <!-- Table to display session requests -->
                <table class="min-w-full bg-white">
                    <thead>
                        <tr>
                            <!-- Table headers -->
                            <th class="py-2 px-4 border-b">Status</th>
                            <th class="py-2 px-4 border-b">Subject</th>
                            <th class="py-2 px-4 border-b">Date</th>
                            <th class="py-2 px-4 border-b">Start Time</th>
                            <th class="py-2 px-4 border-b">End Time</th>
                            <th class="py-2 px-4 border-b">Location</th>
                            <th class="py-2 px-4 border-b">Tutor</th>
                            <th class="py-2 px-4 border-b">Tutoree</th>
                            <th class="py-2 px-4 border-b">Actions</th>

                        </tr>
                    </thead>
                    <tbody>
                         <!-- Loop through all pending session requests -->
                        <?php $__currentLoopData = $pendingSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <!-- Display session status with different colors -->
                                <td class="py-2 px-4 border-b text-center"> 
                                    <?php if($session->status == 'Pending'): ?>
                                        <p class="text-yellow-500"><?php echo e($session->status); ?></p>
                                    <?php elseif($session->status == 'Accepted'): ?>
                                        <p class="text-green-500"><?php echo e($session->status); ?></p>
                                    <?php elseif($session->status == 'Denied'): ?>
                                        <p class="text-red-500"><?php echo e($session->status); ?></p>
                                    <?php endif; ?>
                                </td>
                                 <!-- Display session details -->
                                <td class="py-2 px-4 border-b text-center"><?php echo e($session->subject); ?></td>
                                <td class="py-2 px-4 border-b text-center"><?php echo e($session->date); ?></td>
                                <td class="py-2 px-4 border-b text-center"><?php echo e((new DateTime($session->start_time))->format('h:i A')); ?></td>
                                <td class="py-2 px-4 border-b text-center"><?php echo e((new DateTime($session->end_time))->format('h:i A')); ?></td>
                                <td class="py-2 px-4 border-b text-center"><?php echo e($session->location); ?></td>

                                <!-- If there is a tutor -->
                                <?php if(!is_null($session->tutor)): ?>
                                    <td class="py-2 px-4 border-b text-center"><?php echo e($session->tutor->user->first_name); ?></td> 
                                <?php else: ?> 
                                    <td class="py-2 px-4 border-b text-center"> Finding Tutor </td> 
                                <?php endif; ?>
                                <td class="py-2 px-4 border-b text-center"> <?php echo e($session->tutoree->first_name); ?></td>

                                 <!-- Session is pending -->
                                <?php if($session->status == 'Pending'): ?>
                                    <td class="py-2 px-4 flex justify-center items-center gap-2">
                                        <?php if(auth()->guard()->check()): ?>
                                            <!-- If user is a tutor or tutoree id matches -->
                                            <?php if(Auth::user()->role == 'tutor' && Auth::user()->tutor->id == $session->tutor_id): ?>
                                                <form action="<?php echo e(route('sessions.accept-session-request', $session->id)); ?>" method="POST" class="inline-block">
                                                    <?php echo csrf_field(); ?>
                                                    <!-- Hidden fields for session data -->
                                                    <input type="hidden" name="session_id" value="<?php echo e($session->id); ?>">
                                                    <input type="hidden" name="tutor_id" value="<?php echo e($session->tutor_id); ?>">
                                                    <input type="hidden" name="subject" value="<?php echo e($session->subject); ?>">
                                                    <input type="hidden" name="date" value="<?php echo e($session->date); ?>">
                                                    <input type="hidden" name="start_time" value="<?php echo e($session->start_time); ?>">
                                                    <input type="hidden" name="end_time" value="<?php echo e($session->end_time); ?>">
                                                    <input type="hidden" name="location" value="<?php echo e($session->location); ?>">
                                                    <input type="hidden" name="tutoree_id" value="<?php echo e($session->tutoree_id); ?>">
                                                    <input type="hidden" name="reason" value="<?php echo e($session->reason); ?>">
                                                    <input type="hidden" name="status" value="<?php echo e($session->status); ?>">
                                                    <button type="submit" class="bg-green-500 text-white py-1 px-3 rounded hover:bg-green-600">Accept</button>
                                                </form>
                                                <!-- Decline button for admins -->
                                                <a href="<?php echo e(route('sessions.deny-session', $session->id)); ?>">
                                                    <button class="bg-red-500 text-white py-1 px-3 rounded hover:bg-red-600">Decline</button>
                                                </a>
                                            <?php elseif(Auth::user()->role == 'tutoree' || Auth::user()->id == $session->tutoree_id): ?>
                                                <!-- Cancel button for tutorees -->
                                                <form action="<?php echo e(route('sessions.cancel-session-request', $session->id)); ?>" method="POST" class="inline-block">
                                                    <?php echo csrf_field(); ?>
                                            
                                                    <button type="submit" class="bg-red-500 text-white py-1 px-3 rounded hover:bg-red-600">Cancel</button>
                                                </form>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                <!-- If session has been accepted or declined -->  
                                <?php elseif($session->status == 'Accepted' || $session->status == 'Denied'): ?>
                                <td class="py-2 px-4 border-b flex justify-center">
                                    <!-- Archive action for completed/denied sessions -->
                                    <form action="<?php echo e('archive-session-request/' . $session->id); ?>" method="POST" class="inline-block">
                                        <?php echo csrf_field(); ?>
                                        <!-- Hidden fields for session data -->
                                        <input type="hidden" name="session_id" value="<?php echo e($session->id); ?>">
                                        <input type="hidden" name="tutor_id" value="<?php echo e($session->tutor_id); ?>">
                                        <input type="hidden" name="subject" value="<?php echo e($session->subject); ?>">
                                        <input type="hidden" name="date" value="<?php echo e($session->date); ?>">
                                        <input type="hidden" name="start_time" value="<?php echo e($session->start_time); ?>">
                                        <input type="hidden" name="end_time" value="<?php echo e($session->end_time); ?>">                                    
                                        <input type="hidden" name="location" value="<?php echo e($session->location); ?>">
                                        <input type="hidden" name="tutoree_id" value="<?php echo e($session->tutoree_id); ?>">
                                        <input type="hidden" name="reason" value="<?php echo e($session->reason); ?>">
                                        <input type="hidden" name="status" value="<?php echo e($session->status); ?>">
                                        <!-- Archive button -->
                                        <button type="submit" class="bg-gray-500 text-white py-1 px-3 rounded hover:bg-gray-600">Archive</button>
                                    </form>
                                <?php endif; ?>
                                </td>
                            
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\score\resources\views/pages/tutor-sessions/pending-sessions.blade.php ENDPATH**/ ?>