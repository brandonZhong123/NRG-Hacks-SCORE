
<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Users')]); ?>
    <div class="container mx-auto py-8 overflow-auto">
        <div class="flex items-center justify-between mb-6">
            <!-- Courses Header -->
            <h2 class="text-2xl font-semibold text-gray-800">Courses</h2>

            <?php echo $__env->make('partials._pagination-text', ['paginator' => $courses], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('partials._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
         <!-- Add new course button -->
        <div class="mb-6">
            <a href="<?php echo e(route('courses.add')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">
                Add New Course
            </a>
        </div>

        <!-- Courses Table -->
        <div class="bg-white rounded-lg overflow-auto w-full">
            <table class="min-w-full leading-normal border-spacing-8">
                <thead>
                    <tr>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Code
                        </th>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Subject
                        </th>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Type
                        </th>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Grade
                        </th>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody>
                     <!-- Course information loop -->
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="mb-4">
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-lg">
                                <p class="text-gray-900 whitespace-no-wrap"><?php echo e($course->code); ?></p>
                            </td>
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-lg">
                                <p class="text-gray-900 whitespace-no-wrap"><?php echo e($course->subject); ?></p>
                            </td>
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-lg ">
                                <p class="text-gray-900 whitespace-no-wrap"><?php echo e(($course->type)); ?></p>
                            </td>
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-lg ">
                                <p class="text-gray-900 whitespace-no-wrap"><?php echo e(($course->grade)); ?></p>
                            </td>
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-lg text-center">
                                <a href="<?php echo e(route('courses.edit', $course->id)); ?>" class="text-blue-500 hover:text-blue-700 mr-3">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
         <!-- Paginator -->
        <div class="mt-6">
            <?php echo $__env->make('partials._pagination', ['paginator' => $courses], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/pages/courses/courses.blade.php ENDPATH**/ ?>