<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Application Details']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Application Details')]); ?>
    <div class="p-6">
        <h1 class="text-2xl font-semibold text-gray-800 mb-6">Application Details</h1>
        
        <!-- All application detials -->
        <div class="bg-white shadow-lg rounded-lg p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">User Information</h2>
            <p><strong>Name:</strong> <?php echo e($application->user->first_name); ?> <?php echo e($application->user->last_name); ?></p>
            <p><strong>Email:</strong> <?php echo e($application->user->email); ?></p>
            <p><strong>Phone Number:</strong> <?php echo e($application->phone_number); ?></p>
            
            <h2 class="text-xl font-semibold text-gray-800 mb-4 mt-6">Application Information</h2>
            <p><strong>Subjects:</strong> 
                <?php $__currentLoopData = json_decode($application->subjects); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($subject . ','); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <p><strong>Availability:</strong> <?php echo e($application->availability); ?></p>
            <p><strong>Description:</strong> <?php echo e($application->description); ?></p>
            <p><strong>Experience:</strong> <?php echo e($application->experience); ?></p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\score\resources\views/pages/tutors/tutor-application-details.blade.php ENDPATH**/ ?>