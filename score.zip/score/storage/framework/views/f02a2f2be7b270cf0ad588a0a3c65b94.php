<!-- Side Bar -->
<div class="bg-gray-800 text-white h-full w-64 shadow-lg overflow-auto">
    <div class="p-4">

        <h2 class="text-xl font-semibold mb-6 border-b pb-8">Peer Tutor</h2>

        <!-- Side Bar UL -->
        <ul class="space-y-4">

            <!-- Dashboard link -->
            <li>
                <a href="/dashboard" class="flex items-center text-lg hover:bg-gray-700 p-2 rounded-lg">
                    <i class="fas fa-tachometer-alt w-6 h-6 mr-3"></i>
                    Dashboard
                </a>
            </li>

             <!-- Sessions link -->
            <li>
                <a href="/sessions" class="flex items-center text-lg hover:bg-gray-700 p-2 rounded-lg">
                    <i class="fas fa-calendar-alt w-6 h-6 mr-3"></i>
                    Sessions
                </a>
            </li>

            <!-- If user is tutor or admin display global session requests-->
            <?php if(Auth::user()->role == 'tutor' || Auth::user()->role == 'admin'): ?>
                <li>
                    <a href="/sessions/pending-random-sessions" class="flex items-center text-lg hover:bg-gray-700 p-2 rounded-lg">
                        <i class="fas fa-user-clock w-6 h-6 mr-3"></i>
                        Global Session Requests
                    </a>
                </li>
            <?php endif; ?>

            <!-- Pending Sessions / Personal Session requests link-->
            <li>
                <a href="/sessions/pending-sessions" class="flex items-center text-lg hover:bg-gray-700 p-2 rounded-lg">
                    <i class="fas fa-calendar-alt w-6 h-6 mr-3"></i>
                    <?php echo e(// If user is tutoree display outgoing session requests otherwise display personal session requests
                        Auth::user()->role == 'tutoree' ? 'Outgoing Session Requests' : 'Personal Session Requests'); ?>

                </a>
            </li>

            <!-- Users and Courses link for admins-->
            <?php if(Auth::user()->role == 'admin'): ?>
                <li>
                    <a href="/users" class="flex items-center text-lg hover:bg-gray-700 p-2 rounded-lg">
                        <i class="fas fa-users w-6 h-6 mr-3"></i>
                        Users
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('courses')); ?>" class="flex items-center text-lg hover:bg-gray-700 p-2 rounded-lg">
                        <i class="fas fa-book w-6 h-6 mr-3"></i>
                        Courses
                    </a>
                </li>
            <?php endif; ?>

            <!-- Tutors link -->
            <li>
                <a href="/tutors" class="flex items-center text-lg hover:bg-gray-700 p-2 rounded-lg">
                    <i class="fas fa-chalkboard-teacher w-6 h-6 mr-3"></i>
                    Tutors
                </a>
            </li>

            <!-- Profile Link -->
            <li>
                <a href="<?php echo e(route('users.update', Auth::user()->id)); ?>" class="flex items-center text-lg hover:bg-gray-700 p-2 rounded-lg">
                    <i class="fas fa-user-circle mr-3"></i>
                    Profile
                </a>
            </li>

            <!-- Pending Applications link -->
            <?php if(Auth::user()->role == 'admin' || Auth::user()->role == 'tutoree'): ?>
                <li>
                    <a href="<?php echo e(route('tutors.pending-applications')); ?>" class="flex items-center text-lg hover:bg-gray-700 p-2 rounded-lg">
                        <i class="fas fa-clock mr-3"></i>
                        Outgoing tutor Applications
                    </a>
                </li>
            <?php endif; ?>
            
        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/components/sidebar.blade.php ENDPATH**/ ?>