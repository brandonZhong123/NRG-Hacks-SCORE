<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Sessions']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Sessions')]); ?>
    <!-- Main Content -->
    <div class="p-6 flex-1 overflow-y-auto">
        <!-- Page heading -->
        <h2 class="text-2xl font-semibold mb-6">Scheduled Sessions</h2>

        <!-- Check if there are any sessions -->
        <?php if($sessions->isEmpty()): ?>
            <!-- Display message based on the user's role -->
            <?php if(Auth::user()->role != 'admin'): ?>
                <p class="text-gray-600">You have no pending sessions.</p> 
            <?php else: ?> 
                <p class="text-gray-600">No pending sessions.</p> 
            <?php endif; ?>
        <?php else: ?>
            <!-- Display table for sessions -->
            <div class="overflow-x-auto w-full">
                <table class="w-full bg-white shadow-md rounded-lg border border-gray-300">
                    <thead>
                        <tr class="bg-gray-200 text-gray-700 border-b border-gray-300">
                            <!-- Table headers -->
                            <th class="py-3 px-6 text-left border-r border-gray-300">Status</th>
                            <th class="py-3 px-6 text-left border-r border-gray-300">Date</th>
                            <th class="py-3 px-6 text-left border-r border-gray-300">Start Time</th>
                            <th class="py-3 px-6 text-left border-r border-gray-300">End Time</th>
                            <th class="py-3 px-6 text-left border-r border-gray-300">Tutor</th>
                            <th class="py-3 px-6 text-left border-r border-gray-300">Tutoree</th>
                            <th class="py-3 px-6 text-left border-r border-gray-300">Subject</th>
                            <th class="py-3 px-6 text-left">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Loop through each session -->
                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-100">
                                <!-- Display session status with different colors -->
                                <td class="py-4 px-6 border-r border-gray-300"> 
                                    <?php if($session->status == 'Ongoing'): ?>
                                        <p class="text-yellow-500"><?php echo e($session->status); ?></p>
                                    <?php elseif($session->status == 'Completed'): ?>
                                        <p class="text-green-500"><?php echo e($session->status); ?></p>
                                    <?php elseif($session->status == 'Cancelled'): ?>
                                        <p class="text-red-500"><?php echo e($session->status); ?></p>
                                    <?php endif; ?>
                                </td>
                                <!-- Display session details -->
                                <td class="py-4 px-6 border-r border-gray-300"><?php echo e($session->date); ?></td>
                                <td class="py-4 px-6 border-r border-gray-300"><?php echo e((new DateTime($session->start_time))->format('h:i A')); ?></td>
                                <td class="py-4 px-6 border-r border-gray-300"><?php echo e((new DateTime($session->end_time))->format('h:i A')); ?></td>
                                <td class="py-4 px-6 border-r border-gray-300"><?php echo e($session->tutor->user->first_name); ?></td>
                                <td class="py-4 px-6 border-r border-gray-300"><?php echo e($session->tutoree->first_name); ?></td>
                                <td class="py-4 px-6 border-r border-gray-300"><?php echo e($session->subject); ?></td>

                                <!-- Display actions based on session status -->
                                <?php if($session->status == 'Ongoing'): ?>
                                    <td class="py-4 px-6">  
                                        <div class="flex items-center gap-1">
                                            <!-- Button to mark session as completed -->
                                            <?php if(Auth::user()->role == 'tutor' || Auth::user()->role == 'admin'): ?>
                                                <form action="<?php echo e('sessions/complete-session/' . $session->id); ?>" method="POST" class="">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <button class="bg-blue-500 whitespace-nowrap text-white py-2 px-4 rounded-full hover:bg-blue-600">Mark As Completed</button>  
                                                </form>      
                                            <?php endif; ?>
                                            <!-- Button to cancel the session -->
                                            <a href="<?php echo e(route('sessions.cancel-session-reason', $session->id)); ?>">
                                                <button class="bg-red-500 text-white py-2 px-4 rounded-full hover:bg-red-600">Cancel</button>
                                            </a>
                                        </div>
                                    </td>
                                <?php elseif($session->status == 'Completed' || $session->status == 'Cancelled'): ?>
                                    <td class="py-4 px-6">  
                                        <div class="flex space-x-3">
                                            <!-- Button to archive session -->
                                            <form action="<?php echo e('sessions/archive-session/' . $session->id); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <!-- Hidden input fields for session data -->
                                                <input type="hidden" name="session_id" value="<?php echo e($session->id); ?>">
                                                <input type="hidden" name="tutor_id" value="<?php echo e($session->tutor_id); ?>">
                                                <input type="hidden" name="subject" value="<?php echo e($session->subject); ?>">
                                                <input type="hidden" name="date" value="<?php echo e($session->date); ?>">
                                                <input type="hidden" name="start_time" value="<?php echo e($session->start_time); ?>">
                                                <input type="hidden" name="end_time" value="<?php echo e($session->end_time); ?>">
                                                <input type="hidden" name="location" value="<?php echo e($session->location); ?>">
                                                <input type="hidden" name="tutoree_id" value="<?php echo e($session->tutoree_id); ?>">
                                                <input type="hidden" name="reason" value="<?php echo e($session->reason); ?>">
                                                <input type="hidden" name="status" value="<?php echo e($session->status); ?>">
                                                <button type="submit" class="bg-gray-500 text-white py-2 px-4 rounded-full hover:bg-gray-600">Archive</button>  
                                            </form>      
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/pages/tutor-sessions/tutor-sessions.blade.php ENDPATH**/ ?>