<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Tutor Applications']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Tutor Applications')]); ?>
    <div class="p-6">
        <h1 class="text-2xl font-semibold text-gray-800 mb-6">Pending Tutor Applications</h1>
        
        <?php if($applications->isEmpty()): ?>
            <p>No pending applications.</p>
        <?php else: ?>
            <!-- Pending application table -->
            <table class="min-w-full bg-white">
                <thead>
                    <tr>
                        <!-- Table headers -->
                        <th class="py-2 px-4 border-b">Status</th>
                        <th class="py-2 px-4 border-b">Name</th>
                        <th class="py-2 px-4 border-b">Email</th>
                        <th class="py-2 px-4 border-b">Details</th>
                        <?php if(Auth::user()->role == 'admin'): ?><th class="py-2 px-4 border-b">Actions</th> <?php endif; ?>
                    
                    </tr>
                </thead>
                <tbody>
                    <!-- Loop for each table row -->
                    <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Status -->
                        <tr class="hover:bg-gray-100">
                            <td class="py-4 px-6 border-b text-center">
                                <?php if($application->status == 'Pending'): ?>
                                    <p class="text-yellow-500"><?php echo e($application->status); ?></p>
                                <?php elseif($application->status == 'Approved'): ?>
                                    <p class="text-green-500"><?php echo e($application->status); ?></p>
                                <?php elseif($application->status == 'Denied'): ?>
                                    <p class="text-red-500"><?php echo e($application->status); ?></p>
                                <?php endif; ?>
                            </td>
                            <!-- Table information -->
                            <td class="py-4 px-6 border-b text-center"><?php echo e($application->user->first_name . ' ' . $application->user->last_name); ?></td>
                            <td class="py-4 px-6 border-b text-center"><?php echo e($application->user->email); ?></td>
                            <td class="py-4 px-6 border-b text-center">
                            <a href="<?php echo e(route('tutors.application-details', $application->id)); ?>" class="text-blue-500 hover:underline">View Details</a>
                            <!-- If user is an admin create a form to approve or decline application-->
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <td class="py-4 px-6 border-b text-center">       
                                    <form action="<?php echo e(route('tutors.approve-application', $application->id)); ?>" method="POST" class="inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button type="submit" class="bg-green-500 text-white py-1 px-3 rounded hover:bg-green-600">Approve</button>
                                    </form>
                                    <form action="<?php echo e(route('tutors.reject-application', $application->id)); ?>" method="POST" class="inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button type="submit" class="bg-red-500 text-white py-1 px-3 rounded hover:bg-red-600">Reject</button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/pages/tutors/pending-tutor-applications.blade.php ENDPATH**/ ?>