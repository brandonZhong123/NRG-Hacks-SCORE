<!-- filepath: /c:/xampp/htdocs/peer_tutor/resources/views/pages/book-session.blade.php -->

<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-6">
        <h1 class="text-2xl font-semibold text-gray-800 mb-6">Book a Session with <?php echo e($tutor->user->first_name); ?></h1>
        <p class="text-gray-600 mb-4">Availability: <?php echo e($tutor->availability); ?></p>

        <!-- Display Tutor's Sessions -->
        <div class="mb-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Scheduled Sessions</h2>
            <?php if($sessions->isEmpty()): ?>
                <p class="text-gray-600">No sessions scheduled.</p>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white">
                        <thead>
                            <tr>
                                <th class="py-2 px-4 border-b">Status</th>
                                <th class="py-2 px-4 border-b">Subject</th>
                                <th class="py-2 px-4 border-b">Date</th>
                                <th class="py-2 px-4 border-b">Start Time</th>
                                <th class="py-2 px-4 border-b">End Time</th>
                                <th class="py-2 px-4 border-b">Location</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="py-2 px-4 border-b text-center">
                                        <?php if($session->status == 'Ongoing'): ?>
                                            <p class="text-yellow-500"><?php echo e($session->status); ?></p>
                                        <?php elseif($session->status == 'Completed'): ?>
                                            <p class="text-green-500"><?php echo e($session->status); ?></p>
                                        <?php elseif($session->status == 'Cancelled'): ?>
                                            <p class="text-red-500"><?php echo e($session->status); ?></p>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-2 px-4 border-b text-center"><?php echo e($session->subject); ?></td>
                                    <td class="py-2 px-4 border-b text-center"><?php echo e($session->date); ?></td>
                                    <td class="py-2 px-4 border-b text-center"><?php echo e((new DateTime($session->start_time))->format('h:i A')); ?></td>
                                    <td class="py-2 px-4 border-b text-center"><?php echo e((new DateTime($session->end_time))->format('h:i A')); ?></td>
                                    <td class="py-2 px-4 border-b text-center"><?php echo e($session->location); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Booking Form -->
        <form action="<?php echo e(route('sessions.pending-session.store')); ?>" method="POST" class="bg-white shadow-lg rounded-lg p-6">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="tutor_id" value="<?php echo e($tutor->id); ?>">
            <div class="mb-4">
                <label for="subject" class="block text-gray-700">Subject</label>
                <input type="text" id="subject" name="subject" class="w-full p-2 border border-gray-300 rounded-lg" required>
            </div>
            <div class="mb-4">
                <label for="date" class="block text-gray-700">Date</label>
                <input type="date" id="date" name="date" class="w-full p-2 border border-gray-300 rounded-lg" required>
            </div>
            <div class="mb-4">
                <label for="start_time" class="block text-gray-700">Start Time</label>
                <input type="time" id="start_time" name="start_time" class="w-full p-2 border border-gray-300 rounded-lg" required>
            </div>
            <div class="mb-4">
                <label for="start_time" class="block text-gray-700">End Time</label>
                <input type="time" id="time" name="end_time" class="w-full p-2 border border-gray-300 rounded-lg" required>
            </div>
            <div class="mb-4">
                <label for="location" class="block text-gray-700">Location</label>
                <input type="text" id="location" name="location" class="w-full p-2 border border-gray-300 rounded-lg" required>
            </div>
            <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded-full hover:bg-blue-600">Book Session</button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/pages/book-session.blade.php ENDPATH**/ ?>