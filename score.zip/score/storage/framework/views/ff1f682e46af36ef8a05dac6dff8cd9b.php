<!-- filepath: /c:/xampp/htdocs/peer_tutor/resources/views/pages/tutors.blade.php -->
<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex-1 p-6">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-semibold">Available Tutors</h2>
            <div class="mx-auto hidden font-semibold md:block">
                <?php if($tutors->count() > 0): ?>
                    Showing <?php echo e($tutors->firstItem()); ?> to <?php echo e($tutors->lastItem()); ?> of <?php echo e($tutors->total()); ?> results
                <?php endif; ?>
            </div>
            <form method="GET" class="w-full sm:ml-auto sm:mt-0 sm:w-auto md:ml-0 relative flex items-center">
                <input name="search" type="text" placeholder="Search tutors..." value="<?php echo e(request('search')); ?>" class="border border-gray-300 rounded-lg py-2 px-4 w-full focus:outline-none focus:ring focus:border-blue-300 mr-2">
                <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded-lg">Search</button>
            </form>
        </div>
        <form method="GET" class="mb-6 w-full sm:ml-auto sm:mt-0 sm:w-auto md:ml-0 relative flex items-center">
            <select name="subject" class="border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring focus:border-blue-300 mr-2">
                <option value="">All Subjects</option>
                <option value="MHF4U" <?php echo e(request('subject') == 'MHF4U' ? 'selected' : ''); ?>>MHF4U</option>
                <option value="ICS4U" <?php echo e(request('subject') == 'ICS4U' ? 'selected' : ''); ?>>ICS4U</option>
                <option value="MCR3U" <?php echo e(request('subject') == 'MCR3U' ? 'selected' : ''); ?>>MCR3U</option>
                <option value="History" <?php echo e(request('subject') == 'History' ? 'selected' : ''); ?>>History</option>
                <!-- Add more subjects as needed -->
            </select>
            <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded-lg">Filter</button>
        </form>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $tutors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white shadow-lg rounded-lg p-4">
                    <img src="<?php echo e(asset('images/default.png')); ?>" alt="<?php echo e($tutor->user->name); ?>" class="w-16 h-16 rounded-full mx-auto">
                    <h2 class="text-lg font-semibold text-gray-700 mt-4"><?php echo e($tutor->user->first_name); ?></h2>
                    <?php if (isset($component)) { $__componentOriginal2dc8c3c2091ea372f8becd3211b07dc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dc8c3c2091ea372f8becd3211b07dc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tutor-subjects','data' => ['tutorSubjects' => $tutor->subjects]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tutor-subjects'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tutorSubjects' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tutor->subjects)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dc8c3c2091ea372f8becd3211b07dc2)): ?>
<?php $attributes = $__attributesOriginal2dc8c3c2091ea372f8becd3211b07dc2; ?>
<?php unset($__attributesOriginal2dc8c3c2091ea372f8becd3211b07dc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dc8c3c2091ea372f8becd3211b07dc2)): ?>
<?php $component = $__componentOriginal2dc8c3c2091ea372f8becd3211b07dc2; ?>
<?php unset($__componentOriginal2dc8c3c2091ea372f8becd3211b07dc2); ?>
<?php endif; ?>
                    <a href="/tutors/<?php echo e($tutor->id); ?>" class="text-blue-500 hover:underline mt-2 block">View Details</a>
                    <a href="/tutors/<?php echo e($tutor->id); ?>/book-session" class="bg-blue-500 text-white py-2 px-4 rounded-full hover:bg-blue-600 mt-4 block text-center">Book Session</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Custom Pagination -->
        <div class="mt-6">
            <?php if (isset($component)) { $__componentOriginal41032d87daf360242eb88dbda6c75ed1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41032d87daf360242eb88dbda6c75ed1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pagination','data' => ['paginator' => $tutors]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tutors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $attributes = $__attributesOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $component = $__componentOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__componentOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/pages/tutors.blade.php ENDPATH**/ ?>