<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination Navigation" class="flex justify-center mt-4">
        <?php if($paginator->onFirstPage()): ?>
            <span class="px-3 py-1 mx-1 bg-gray-200 text-gray-700 rounded cursor-not-allowed">Previous</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="px-3 py-1 mx-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">Previous</a>
        <?php endif; ?>

        <?php $__currentLoopData = $paginator->links()->elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_string($element)): ?>
                <span class="px-3 py-1 mx-1 text-gray-700"><?php echo e($element); ?></span>
            <?php endif; ?>

            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="px-3 py-1 mx-1 bg-blue-500 text-white rounded"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>" class="px-3 py-1 mx-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="px-3 py-1 mx-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">Next</a>
        <?php else: ?>
            <span class="px-3 py-1 mx-1 bg-gray-200 text-gray-700 rounded cursor-not-allowed">Next</span>
        <?php endif; ?>
    </nav>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/partials/_pagination.blade.php ENDPATH**/ ?>