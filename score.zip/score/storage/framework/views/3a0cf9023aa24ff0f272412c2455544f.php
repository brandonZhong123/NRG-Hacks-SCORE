<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Main Content -->
    <div class="p-6 flex-1 overflow-y-auto">
        <h2 class="text-2xl font-semibold mb-6">Scheduled Sessions</h2>
        <div class="overflow-x-auto w-full">
            <table class="w-full bg-white shadow-md rounded-lg border border-gray-300">
                <thead>
                    <tr class="bg-gray-200 text-gray-700 border-b border-gray-300">
                        <th class="py-3 px-6 text-left border-r border-gray-300">Date</th>
                        <th class="py-3 px-6 text-left border-r border-gray-300">Time</th>
                        <th class="py-3 px-6 text-left border-r border-gray-300">Tutor</th>
                        <th class="py-3 px-6 text-left border-r border-gray-300">Subject</th>
                        <th class="py-3 px-6 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="border-b hover:bg-gray-100">
                        <td class="py-4 px-6 border-r border-gray-300">2025-01-15</td>
                        <td class="py-4 px-6 border-r border-gray-300">10:00 AM</td>
                        <td class="py-4 px-6 border-r border-gray-300">John Doe</td>
                        <td class="py-4 px-6 border-r border-gray-300">Mathematics</td>
                        <td class="py-4 px-6">
                            <div class="flex space-x-3">
                                <button class="bg-blue-500 text-white py-2 px-4 rounded-full hover:bg-blue-600">Details</button>
                                <button class="bg-red-500 text-white py-2 px-4 rounded-full hover:bg-red-600">Cancel</button>
                            </div>
                        </td>
                    </tr>
                    <tr class="border-b hover:bg-gray-100">
                        <td class="py-4 px-6 border-r border-gray-300">2025-01-16</td>
                        <td class="py-4 px-6 border-r border-gray-300">2:00 PM</td>
                        <td class="py-4 px-6 border-r border-gray-300">Jane Smith</td>
                        <td class="py-4 px-6 border-r border-gray-300">Physics</td>
                        <td class="py-4 px-6">
                            <div class="flex space-x-3">
                                <button class="bg-blue-500 text-white py-2 px-4 rounded-full hover:bg-blue-600">Details</button>
                                <button class="bg-red-500 text-white py-2 px-4 rounded-full hover:bg-red-600">Cancel</button>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/welcome.blade.php ENDPATH**/ ?>