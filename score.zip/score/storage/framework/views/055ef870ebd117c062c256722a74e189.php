<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Update Profile']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Update Profile')]); ?>
    <div class="bg-gray-100 flex justify-center items-center" style="min-height: 80vh;">
        <div class="bg-white shadow-md rounded-lg w-full max-w-4xl p-6 ">

            <!-- User name, profile picture and role -->
            <div class="flex items-center mb-6">
                <img src="<?php echo e(asset('images/default.png')); ?>" alt="Profile Picture" class="w-20 h-20 rounded-full mr-4">
                <div>
                    <h2 class="text-xl font-bold"><?php echo e($user->first_name . ' ' . $user->last_name); ?></h2>
                    <p class="text-gray-500"><?php echo e(Str::ucFirst($user->role)); ?></p>
                </div>
            </div>

                <h3 class="text-lg font-semibold mb-4 border-b pb-2">User Information</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                     <!-- User first name -->
                    <div>
                        <h1 class="block text-sm font-medium text-gray-700">First Name</label>
                        <p class="mt-1 block w-full rounded-md"> 
                            <?php echo e($user->first_name); ?>

                        </p>
                    </div>

                     <!-- User last name -->
                    <div>
                        <h1 class="block text-sm font-medium text-gray-700">Last Name</label>
                        <p class="mt-1 block w-full rounded-md "> 
                            <?php echo e($user->last_name); ?>

                        </p>
                    </div>

                     <!-- User email-->
                    <div>
                        <h1 class="block text-sm font-medium text-gray-700">Email</label>
                        <p class="mt-1 block w-full rounded-md "> 
                            <?php echo e($user->email); ?>

                        </p>
                    </div>

                     <!-- User role -->
                    <div>
                        <h1 class="block text-sm font-medium text-gray-700">Role</label>
                        <p class="mt-1 block w-full rounded-md"> 
                            <?php echo e($user->role); ?>

                        </p>
                    </div>
                </div>
    
                <!-- Tutor Information -->
                <?php if(Auth::user()->role == 'admin'): ?>
                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class= "text-blue-500 hover:text-blue-600 hover:underline cursor-pointer "> Edit profile </a>
                <?php endif; ?>

                <?php if(Auth::user()->role == 'tutor'): ?>
                    <a href="<?php echo e(route('tutors.show', $user->tutor->id)); ?>" class= "text-blue-500 hover:text-blue-600 hover:underline cursor-pointer "> View tutor profile </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/pages/users/profile.blade.php ENDPATH**/ ?>