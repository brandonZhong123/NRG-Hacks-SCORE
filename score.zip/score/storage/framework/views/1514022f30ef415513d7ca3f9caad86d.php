
<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex-1 flex flex-col">
        <div class="flex-1 p-6 overflow-auto">
            <div class="bg-white shadow-lg rounded-lg p-6">
                <h1 class="text-2xl font-semibold text-gray-800">Overview of Your Tutoring Activities</h1>
                <p class="text-sm text-gray-500 mt-2">Here’s a summary of your sessions and other activities.</p>
    
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-6">
                    <!-- Upcoming Sessions -->
                    <div class="bg-gray-100 p-4 rounded-lg shadow">
                        <h2 class="text-lg font-semibold text-gray-700">Upcoming Sessions</h2>
                        <ul class="mt-2 space-y-4">
                            <li class="flex justify-between">
                                <span>Math Session</span>
                                <span class="text-gray-500">Mon, 5 PM</span>
                            </li>
                            <li class="flex justify-between">
                                <span>Science Session</span>
                                <span class="text-gray-500">Tue, 4 PM</span>
                            </li>
                        </ul>
                    </div>
                    
                    <!-- Messages -->
                    <div class="bg-gray-100 p-4 rounded-lg shadow">
                        <h2 class="text-lg font-semibold text-gray-700">Messages</h2>
                        <p class="mt-2 text-sm text-gray-500">You have 2 new messages from your tutor.</p>
                        <button class="mt-4 bg-blue-500 text-white py-2 px-4 rounded-full">View Messages</button>
                    </div>
    
                    <!-- Stats -->
                    
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>