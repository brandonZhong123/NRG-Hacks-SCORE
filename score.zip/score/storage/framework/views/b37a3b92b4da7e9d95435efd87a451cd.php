<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Profile']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Profile')]); ?>
    <div class="bg-gray-100 flex items-center justify-center min-h-screen" style="min-height: 80vh;">
        <div class="bg-white shadow-lg rounded-lg p-6 max-w-xl w-full">
            <!-- Profile Picture -->
            <div class="flex justify-center">
                <img
                    class="w-32 h-32 rounded-full border-4 border-blue-500 object-cover"
                    src="<?php echo e(asset('images/default.png')); ?>"
                    alt="Profile Picture"
                />
            </div>
            <!-- Name and Title -->
            <div class="text-center mt-4">
                <h2 class="text-xl font-bold text-gray-800"><?php echo e($tutor->user->first_name); ?> <?php echo e($tutor->user->last_name); ?></h2>
                <p class="text-gray-600">Tutor</p>
            </div>
            <!-- Bio -->
            <div class="mt-4 text-center">
                <h3 class="text-lg font-semibold text-gray-800">About</h3>
                <p class="text-gray-700 mt-2"><?php echo e($tutor->description); ?></p>
            </div>
            <!-- Subjects -->
            <div class="mt-4 text-center">
                <h3 class="text-lg font-semibold text-gray-800">Subjects</h3>
                <div class="flex flex-wrap justify-center gap-2 mt-2">
                    <?php $__currentLoopData = json_decode($tutor->subjects); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="px-3 py-1 bg-orange-100 text-blue-800 rounded-full text-sm">
                            <?php echo e(trim($subject)); ?>

                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <!-- Action Buttons -->
            <div class="mt-6 flex justify-around">
                <?php if(Auth::id() !== $tutor->user_id): ?>
                    <a href="<?php echo e(route('tutors.book-session', $tutor)); ?>" class="bg-orange-500 w-full text-center text-white px-4 py-2 rounded-lg shadow hover:bg-orange-600">
                        Book Session
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\score\resources\views/pages/tutors/tutor-profile.blade.php ENDPATH**/ ?>