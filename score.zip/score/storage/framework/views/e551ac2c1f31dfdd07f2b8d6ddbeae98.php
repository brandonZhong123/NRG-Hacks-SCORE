
<?php
    // Turn a course table field into an array
    $courses = App\Models\Course::pluck('code')->toArray();
?>

<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Tutors']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Tutors')]); ?>
    <div class="flex-1 p-6">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-semibold">Available Tutors</h2>
           
            <!-- Pagination text and search bar -->
            <?php echo $__env->make('partials._pagination-text', ['paginator' => $tutors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('partials._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        </div>
        <!-- Filter -->
        <?php echo $__env->make('partials._filter', ['list' => $courses, 'filter' => 'subject', 'filter_name' => 'All Subjects'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Tutors grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $tutors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white shadow-lg rounded-lg p-4">
                    <!-- Display tutor name, subjects, details link and book session link -->
                    <img src="<?php echo e(asset('images/default.png')); ?>" alt="<?php echo e($tutor->user->name); ?>" class="w-16 h-16 rounded-full mx-auto">
                    <h2 class="text-lg font-semibold text-gray-700 mt-4"><?php echo e($tutor->user->first_name . ' ' . $tutor->user->last_name); ?></h2>
                    <?php if (isset($component)) { $__componentOriginal2dc8c3c2091ea372f8becd3211b07dc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dc8c3c2091ea372f8becd3211b07dc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tutor-subjects','data' => ['tutorSubjects' => $tutor->subjects]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tutor-subjects'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tutorSubjects' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tutor->subjects)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dc8c3c2091ea372f8becd3211b07dc2)): ?>
<?php $attributes = $__attributesOriginal2dc8c3c2091ea372f8becd3211b07dc2; ?>
<?php unset($__attributesOriginal2dc8c3c2091ea372f8becd3211b07dc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dc8c3c2091ea372f8becd3211b07dc2)): ?>
<?php $component = $__componentOriginal2dc8c3c2091ea372f8becd3211b07dc2; ?>
<?php unset($__componentOriginal2dc8c3c2091ea372f8becd3211b07dc2); ?>
<?php endif; ?>
                    <a href="/tutors/<?php echo e($tutor->id); ?>" class="text-blue-500 hover:underline mt-2 block">View Details</a>
                    <a href="/tutors/<?php echo e($tutor->id); ?>/book-session" class="bg-blue-500 text-white py-2 px-4 rounded-full hover:bg-blue-600 mt-4 block text-center">Book Session</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Custom Pagination -->
        <div class="mt-6">
            <?php echo $__env->make('partials._pagination', ['paginator' => $tutors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\peer_tutor\resources\views/pages/tutors/tutors.blade.php ENDPATH**/ ?>