<div class="bg-white text-gray-800 shadow p-4 flex justify-between items-center w-full ">

    <!-- Page heading -->
    <div class="text-xl font-semibold">
       <?php echo e($pageHeading); ?> 
    </div>
    <div class="flex items-center gap-2">

        <!-- If user is a student -->
        <?php if(Auth::user()->role == 'student'): ?>
            <!-- Display random session booking link and tutor application link -->
            <a href="<?php echo e(route('tutors.submit-application')); ?>">
                <button class="bg-orange-500 px-4 py-2 rounded-full text-white hover:bg-orange-600">Apply For Tutor</button>
            </a>
        <!-- If user is a tutor -->
        <?php elseif(Auth::user()->role == 'tutor'): ?>
            <!-- If user status is enabled -->
            <?php if(Auth::user()->tutor->status == 'enabled'): ?>
                 <!-- Allow user to deactivate -->
                <form method="POST" action="<?php echo e(route('tutors.deactivate')); ?>"  >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <button type="submit" class="bg-red-500 text-white py-2 px-4 rounded-full hover:bg-gray-600">Deactivate Tutor Profile</button>
                </form>
            <!-- If user status is disabled -->
            <?php elseif(Auth::user()->tutor->status == 'disabled'): ?>
                <!-- Allow user to enable -->
                <form method="POST" action="<?php echo e(route('tutors.activate')); ?>"   >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <button type="submit" class="bg-green-500 text-white py-2 px-4 rounded-full hover:bg-green-600">Activate Tutor Profile</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>

        <a href="<?php echo e(route('sessions.book-random-session')); ?>">
            <button class="bg-gray-500 px-4 py-2 rounded-full text-white hover:bg-gray-600">Request a Random Tutor Session</button>
        </a>

        <!-- Logout button -->
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="bg-red-500 text-white py-2 px-4 rounded-full hover:bg-red-600">Logout</button>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\score\resources\views/components/topbar.blade.php ENDPATH**/ ?>