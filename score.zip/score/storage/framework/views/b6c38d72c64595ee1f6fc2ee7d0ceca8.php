<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'hello' ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('hello' )]); ?>
    <?php
    $grade = 0;
    $totalWeightAbundance = 0;

    for ($i = 0; $i < count($individualCourse->assessments); $i++) {
        $totalWeightAbundance += $individualCourse->assessments[$i]->weight;
    }
    ?>
    <div class="flex justify-center items-center h-screen bg-gray-100 p-4">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-4xl border border-gray-300 text-center">
            <h2 class="text-2xl font-semibold text-gray-800 mb-6"><?php echo e($individualCourse->course->code); ?></h2>
            
            <div class="overflow-x-auto">
                <table class="w-full border-collapse mt-4">
                    <thead>
                        <tr class="bg-orange-500 text-white">
                            <th class="p-3 ">Assessment</th>
                            <th class="p-3 ">Grade</th>
                            <th class="p-3 ">Weight</th>
                            <th class="p-3 ">Feedback</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $individualCourse->assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b bg-gray-50 hover:bg-orange-100 transition">
                                <?php
                                $grade += $assessment->mark * ($assessment->weight / $totalWeightAbundance)
                                ?>
                                <td class="p-3"><?php echo e($assessment->name); ?></td>
                                <td class="p-3"><?php echo e($assessment->mark); ?></td>
                                <td class="p-3"><?php echo e($assessment->weight); ?></td>
                                <td class="p-3"><?php echo e($assessment->feedback); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-6 p-4 bg-orange-100 rounded-lg text-lg font-semibold text-gray-800">
                Current Grade: <span class="text-orange-500 font-bold"><?php echo e(round($grade, 2 )); ?>%</span>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\score\resources\views/pages/courses/individual-course.blade.php ENDPATH**/ ?>