<?php
    $roles = ['admin', 'tutor', 'tutoree'];
?>
<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Users')]); ?>
    <div class="container mx-auto py-8 overflow-auto">
        <div class="flex items-center justify-between mb-6">
            <!-- Users Header -->
            <h2 class="text-2xl font-semibold text-gray-800">Users</h2>

            <!-- Search bar and pagination text-->
            <?php echo $__env->make('partials._pagination-text', ['paginator' => $users], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('partials._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <?php echo $__env->make('partials._filter', ['list' => $roles, 'filter' => 'role', 'filter_name' => 'All Roles'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Data List -->
        <div class="bg-white rounded-lg overflow-auto">
            <table class=" w-full leading-normal border-spacing-8">
                <!-- Table headers -->
                <thead>
                    <tr>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Profile
                        </th>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            User Name
                        </th>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Email
                        </th>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Status
                        </th>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Role
                        </th>
                        <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <!-- User rows -->
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="mb-4">

                            <!-- User information -->
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-sm p-6">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 w-12 h-12">
                                        <img class="w-full h-full rounded-full" src="<?php echo e(asset('images/default.png')); ?>" alt="User Profile" />
                                    </div>
                                </div>
                            </td>
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-lg">
                                <p class="text-gray-900 whitespace-no-wrap"><?php echo e($user->first_name . ' ' . $user->last_name); ?></p>
                            </td>
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-lg">
                                <p class="text-gray-900 whitespace-no-wrap"><?php echo e($user->email); ?></p>
                            </td>
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-lg text-center">
                                <span class="relative inline-block px-3 py-1 font-semibold text-green-900 leading-tight">
                                    <span aria-hidden class="absolute inset-0 bg-green-200 opacity-50 rounded-full"></span>
                                    <span class="relative">Active</span>
                                </span>
                            </td>
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-lg text-center">
                                <p class="text-gray-900 whitespace-no-wrap"><?php echo e(ucfirst($user->role)); ?></p>
                            </td>
                            <td class="px-5 py-5 border-b border-gray-200 bg-white text-lg text-center">
                                <div class="flex justify-center">
                                    <a href="<?php echo e(route('users.show', $user->id)); ?>" class="text-blue-500 hover:text-blue-700 mr-3">View</a>
                                    <a href="#" class="text-red-500 hover:text-red-700">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <!-- Custom pagination -->
        <div class="mt-6">
            <?php echo $__env->make('partials._pagination', ['paginator' => $users], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\score\resources\views/pages/users/users.blade.php ENDPATH**/ ?>