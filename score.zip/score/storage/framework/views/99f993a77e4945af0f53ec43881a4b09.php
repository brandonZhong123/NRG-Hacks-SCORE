<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageHeading' => 'Book a Session']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageHeading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Book a Session')]); ?>
    <div class="p-6">
        <h1 class="text-2xl font-semibold text-gray-800 mb-6">Book a Session with <?php echo e($tutor->user->first_name); ?></h1>
        <p class="text-gray-600 mb-4">Availability: <?php echo e($tutor->availability); ?></p>

        <!-- Display Tutor's Sessions -->
        <div class="mb-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Scheduled Sessions</h2>
            <?php if($sessions->isEmpty()): ?>
                <p class="text-gray-600">No sessions scheduled.</p>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white">
                        <thead>
                            <tr>
                                 <!-- Table headers -->
                                <th class="py-2 px-4 border-b">Status</th>
                                <th class="py-2 px-4 border-b">Subject</th>
                                <th class="py-2 px-4 border-b">Date</th>
                                <th class="py-2 px-4 border-b">Start Time</th>
                                <th class="py-2 px-4 border-b">End Time</th>
                                <th class="py-2 px-4 border-b">Location</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Display each session as a table row -->
                            <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <!-- Sessions status -->
                                    <td class="py-2 px-4 border-b text-center">
                                        <?php if($session->status == 'Ongoing'): ?>
                                            <p class="text-yellow-500"><?php echo e($session->status); ?></p>
                                        <?php elseif($session->status == 'Completed'): ?>
                                            <p class="text-green-500"><?php echo e($session->status); ?></p>
                                        <?php elseif($session->status == 'Cancelled'): ?>
                                            <p class="text-red-500"><?php echo e($session->status); ?></p>
                                        <?php endif; ?>
                                    </td>
                                    <!-- Session information -->
                                    <td class="py-2 px-4 border-b text-center"><?php echo e($session->subject); ?></td>
                                    <td class="py-2 px-4 border-b text-center"><?php echo e($session->date); ?></td>
                                    <td class="py-2 px-4 border-b text-center"><?php echo e((new DateTime($session->start_time))->format('h:i A')); ?></td>
                                    <td class="py-2 px-4 border-b text-center"><?php echo e((new DateTime($session->end_time))->format('h:i A')); ?></td>
                                    <td class="py-2 px-4 border-b text-center"><?php echo e($session->location); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Booking Form -->
        <form action="<?php echo e(route('sessions.pending-session.store')); ?>" method="POST" class="bg-white shadow-lg rounded-lg p-6">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="tutor_id" value="<?php echo e($tutor->id); ?>">

            <!-- Subject input -->
            <div class="mb-4">
                <label for="subject" class="block text-sm font-medium text-gray-700">Select Courses</label>
                <select name="subject" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
                    <option value="" disabled selected hidden>Select a course</option>
                    <?php $__currentLoopData = json_decode($tutor->subjects); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($course); ?>" ><?php echo e($course); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Date input -->
            <div class="mb-4">
                <label for="date" class="block text-gray-700">Date</label>
                <input type="date" id="date" name="date" class="w-full p-2 border border-gray-300 rounded-lg" required>
                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Start Time input -->
            <div class="mb-4">
                <label for="start_time" class="block text-gray-700">Start Time</label>
                <input type="time" id="start_time" name="start_time" class="w-full p-2 border border-gray-300 rounded-lg" required>
                <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <!-- End Time input -->
            <div class="mb-4">
                <label for="end_time" class="block text-gray-700">End Time</label>
                <input type="time" id="time" name="end_time" class="w-full p-2 border border-gray-300 rounded-lg" required>
                <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Location -->
            <div class="mb-4">
                <label for="location" class="block text-gray-700">Location</label>
                <input type="text" id="location" name="location" class="w-full p-2 border border-gray-300 rounded-lg" required>
                <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded-full hover:bg-blue-600">Book Session</button>
        </form>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\score\resources\views/pages/tutors/book-session.blade.php ENDPATH**/ ?>