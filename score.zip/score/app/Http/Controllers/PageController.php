<?php

namespace App\Http\Controllers;

use App\Models\PendingTutorSession;
use App\Models\TutorSession;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;


class PageController extends Controller
{
    

    public function dashboard()
    {   
       
        $dashboardContent = [
            'sessions' => Auth::user()->sessions,
            'sessionRequests' => Auth::user()->pendingTutorSessions,
        ];
        
        return view('pages/dashboard/dashboard', compact('dashboardContent'));
    }
}
